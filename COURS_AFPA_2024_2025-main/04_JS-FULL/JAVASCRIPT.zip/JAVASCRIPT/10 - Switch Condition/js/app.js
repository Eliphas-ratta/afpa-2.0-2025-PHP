console.log("Switch Condition");

var favoriteColor = prompt("What's your favorite color");

switch (favoriteColor) {
  case "pink":
    console.log("my favorite color is pink");
    break;
  case "yellow":
    console.log("my favorite color is yellow");
    break;
  case "brown":
    console.log("my favorite color is brown");
    break;
  default:
    console.log("I don't know your color");
}

