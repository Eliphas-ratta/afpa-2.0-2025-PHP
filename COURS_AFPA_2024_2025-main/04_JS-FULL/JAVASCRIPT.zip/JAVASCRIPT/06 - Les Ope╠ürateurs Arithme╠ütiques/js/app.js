console.log("Arithmetic Operators");

//////        //////
//////    +   //////
//////        //////

var result = 2 + 2;
console.log("addition : " + result);

//////        //////
//////    -   //////
//////        //////

result = 3 - 1;
console.log("soustraction : " + result);

//////        //////
//////    /   //////
//////        //////

result = 10 / 5;
console.log("division : " + result);

//////        //////
//////    *   //////
//////        //////
result = 10 * 5;
console.log("multiplication : " + result);

//////                 //////
//////    % (Modulo)   //////
//////                 //////

result = 10 % 3;
console.log("modulo : " + result);
