console.log("Les variables");

var maVariable; // déclaration
// camelCase

// Affectation de valeur
maVariable = "ceci est mon texte";

console.log(maVariable);

var monCalcul = 2 + 2;

console.log(monCalcul);

maVariable = "un autre text";

maVariable = 2;

// Affectation de valeur
var uneNouvelleVariable = maVariable;

console.log(uneNouvelleVariable);
